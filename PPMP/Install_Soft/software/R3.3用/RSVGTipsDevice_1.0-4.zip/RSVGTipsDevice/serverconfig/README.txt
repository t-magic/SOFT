Put the contents of htaccess in a file called ".htaccess" at
the root of a user's webpage to tell Apache how to serve up
SVG files properly.

